﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;
using UserRegstrationWithRoleBaseAuthentication.DataModel;
using UserRegstrationWithRoleBaseAuthentication.Models;

namespace UserRegstrationWithRoleBaseAuthentication.Controllers.api
{
    public class EmployeeAuthoriseAPIController : ApiController
    {
        [BasicAuthentication]
        public HttpResponseMessage GetEmployees()
        {
            string username = Thread.CurrentPrincipal.Identity.Name;
            List<EmployeeRegister> Employees = null;
            using (var DB = new LTDev1111Entities1())
            {
                Employees = DB.tblEmployees.Select(s => new EmployeeRegister()
                {
                    EmployeeName = s.EmployeeName,
                    City = s.City,
                    Email = s.Email,
                    Password = s.Password,
                    Department = s.Department,
                    Roles = s.Roles
                }).ToList<EmployeeRegister>();
            }

            return Request.CreateResponse(HttpStatusCode.OK, Employees);
        }
    }
}

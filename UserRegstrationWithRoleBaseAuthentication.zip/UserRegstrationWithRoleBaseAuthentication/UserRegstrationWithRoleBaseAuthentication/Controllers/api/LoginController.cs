﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UserRegstrationWithRoleBaseAuthentication.DataModel;
using UserRegstrationWithRoleBaseAuthentication.Models;

namespace UserRegstrationWithRoleBaseAuthentication.Controllers.api
{
    public class LoginController : ApiController
    {        
        [HttpPost]
        public IHttpActionResult employeeLogin(Login login)
        {
            using (var DB = new LTDev1111Entities1())
            {
                tblEmployee employee = DB.tblEmployees.Where(x => x.Email.Equals(login.Email) && x.Password.Equals(login.Password)).FirstOrDefault();

                if (employee.Id == 0)
                {
                    return NotFound();
                }

                return Ok(employee);
            }
        }
    }
}

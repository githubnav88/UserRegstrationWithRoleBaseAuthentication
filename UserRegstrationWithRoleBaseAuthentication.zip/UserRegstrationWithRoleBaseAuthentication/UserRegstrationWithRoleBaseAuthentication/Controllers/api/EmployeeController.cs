﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;
using UserRegstrationWithRoleBaseAuthentication.DataModel;
using UserRegstrationWithRoleBaseAuthentication.Models;

namespace UserRegstrationWithRoleBaseAuthentication.Controllers.api
{
    public class EmployeeController : ApiController
    {
        [BasicAuthentication]
        [MyAuthorize(Roles = "Admin")]
        [HttpPost]
        public Response InsertEmployee(EmployeeRegister Reg)
        {
            try
            {
                tblEmployee EL = new tblEmployee();
                using (var DB = new LTDev1111Entities1())
                {
                    if (EL.Id == 0)
                    {
                        EL.EmployeeName = Reg.EmployeeName;
                        EL.City = Reg.City;
                        EL.Email = Reg.Email;
                        EL.Password = Reg.Password;
                        EL.Department = Reg.Department;
                        EL.Roles = Reg.Roles;
                        DB.tblEmployees.Add(EL);
                        DB.SaveChanges();
                        return new Response { Status = "Success", Message = "Record Successfully Saved." };
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return new Response { Status = "Error", Message = "Invalid Data." };
        }

        [BasicAuthentication]
        [MyAuthorize(Roles = "Admin,User")]
        [HttpGet]
        public IHttpActionResult GetAllEmployee()
        {
            IList<EmployeeRegister> Employees = null;

            using (var DB = new LTDev1111Entities1())
            {
                Employees = DB.tblEmployees.Select(s => new EmployeeRegister()
                {
                    EmployeeName = s.EmployeeName,
                    City = s.City,
                    Email = s.Email,
                    Password = s.Password,
                    Department = s.Department,
                    Roles = s.Roles
                }).ToList<EmployeeRegister>();
            }

            return Ok(Employees);
        }        
    }
}

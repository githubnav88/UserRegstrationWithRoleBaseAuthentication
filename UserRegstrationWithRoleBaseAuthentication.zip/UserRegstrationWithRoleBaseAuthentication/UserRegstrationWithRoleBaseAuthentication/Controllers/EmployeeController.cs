﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using UserRegstrationWithRoleBaseAuthentication.Models;
#endregion

namespace UserRegstrationWithRoleBaseAuthentication.Controllers
{
    public class EmployeeController : Controller
    {
        #region All Get Methods
        // Get ALL the employee Details 
        public ActionResult Index()
        {
            IEnumerable<EmployeeRegister> employee = null;
            string baseUrl = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/api/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl);
                //HTTP GET
                var responseTask = client.GetAsync("Employee");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<List<EmployeeRegister>>();
                    readTask.Wait();

                    employee = readTask.Result;
                }
                else
                {
                    employee = Enumerable.Empty<EmployeeRegister>();
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(employee);
        }

        // This is the New Employee creation page
        public ActionResult create()
        {
            return View();
        }

        // GET: Login Page
        public ActionResult Login()
        {
            return View();
        }

        // GET: My Home Page       
        public ActionResult MyProfile()
        {
            return View();
        }
        #endregion

        #region All Post Methods
        [HttpPost]
        public ActionResult create(EmployeeRegister employee)
        {
            // Calling API ......
            string baseUrl = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/api";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl + "/Employee");                
                //HTTP POST
                var postTask = client.PostAsJsonAsync<EmployeeRegister>("Employee", employee);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError(string.Empty, "Server Error....");
            }

            return View(employee);
        }

        [HttpPost] 
        public ActionResult Login(Login login)
        {
            // Calling API ......
            string baseUrl = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/api";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl + "/Login"); 

                //HTTP POST 
                var postTask = client.PostAsJsonAsync<Login>("Login", login);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("MyProfile");
                }
            }

            ModelState.AddModelError(string.Empty, "Wrong EmailID & Password !!!");

            return View(login);
        }
        #endregion
    }
}
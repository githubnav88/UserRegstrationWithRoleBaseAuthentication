﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UserRegstrationWithRoleBaseAuthentication.DataModel;

namespace UserRegstrationWithRoleBaseAuthentication.Models
{
    public class UserValidate
    {
        // This method is used to check the user credentials
        public static tblEmployee Login(string Email, string Password) 
        {
            using (var DB = new LTDev1111Entities1())
            {
                tblEmployee employee = DB.tblEmployees.Where(x => x.Email.Equals(Email) && x.Password.Equals(Password)).FirstOrDefault();                
                return employee;
            }
        }
    }
}
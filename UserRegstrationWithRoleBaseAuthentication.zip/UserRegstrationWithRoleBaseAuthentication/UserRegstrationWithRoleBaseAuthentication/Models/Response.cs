﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserRegstrationWithRoleBaseAuthentication.Models
{
    public class Response
    {
        public string Status { set; get; } 
        public string Message { set; get; }
        public dynamic Data { set; get; }
    }
}